﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello world!");
        }
    }
}
